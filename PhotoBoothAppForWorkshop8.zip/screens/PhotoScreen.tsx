 import {Image, Button, View} from 'react-native';
 import * as Sharing from 'expo-sharing';

 
 
 export default function PhotoScreen(props: any) {
    const onShare = async () => {
    Sharing.shareAsync(props.route.params.uri)
     }

     // C.5 ADD your onPost fucntion here

     return (
        <View style = {{flex : 1}}>
        <Image source={{'uri': props.route.params.uri}} style={{flex: 1}}/>
        <Button title="Share" onPress={onShare}/>
        {/* C.4 Add the "Post" button here to post a photo to the DB */}
        </View>
    );
 }