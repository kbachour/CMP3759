import { useState, useEffect } from 'react';
import { PHOTOS_DIR } from './CameraScreen';
import {View, Image, StyleSheet, ScrollView} from 'react-native';
import {File, Directory} from 'expo-file-system';
import { useFocusEffect } from '@react-navigation/native';

export default function GalleryScreen ()
{
  const [photos, setPhotos] = useState<string []>([]);

  type RowProps =
  {
    photos : string[]
  }

  // E.6 ADD the updatePhotos function here

  useFocusEffect(() => {
      // E.4 REPLACE This with the subscribeToPosts call.
      retrievePhotos();
    }, []
  );

 const retrievePhotos = () => { 
   try {
     const children = PHOTOS_DIR.list(); 
     const currPhotos : string[] = children.filter(item => item instanceof File).map (file => file.uri);

    setPhotos(currPhotos);

   } catch (error) {
     console.log('Error retrieving photos');
   }
 };

  const Row = ({photos} : RowProps) => {
   return(
     <View style={styles.row}>
     {photos.map((photo : string) => (
         <View style={styles.imageContainer} key={photo}>
           <Image source={{'uri': photo}} style={styles.image} />
         </View>
       ))}
     </View>
   );
 } 

 const gallery : React.JSX.Element []= [];
 const rowWidth = 3;
 for (let i = 0; i < (photos.length / rowWidth) + 1; i++) {
   gallery.push(<Row photos={photos.slice(i*rowWidth, i*rowWidth+rowWidth)} key={i}></Row>)
 }

 return <View style = {{flex : 1}}>
     <ScrollView contentContainerStyle={{flexGrow: 1}}>
       {gallery}
     </ScrollView>        
     </View>;
}

 const styles = StyleSheet.create({
   container: {
     height: '100%'
   },
   row: {
     flexDirection: 'row', 
     flex: 1
   },
   imageContainer: {
     width: '33%'
   },
   image: {
     height: 170,
     margin: 2
   }
 });


