
import { useEffect, useRef , useState } from 'react';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Alert, Button,Image, View, Text } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import { File, Paths, Directory } from 'expo-file-system';

export const PHOTOS_DIR = new Directory(Paths.document, 'MAD_Photos');

export default function CameraScreen(props : any) {
  const [permission, requestPermission] = useCameraPermissions();
  const isFocused = useIsFocused();
  const cameraRef = useRef<CameraView>(null);
  const [photoURI, setPhotoURI] = useState('');


  useEffect(() => {
    if (!permission?.granted) {
      requestPermission();
    }
    try{
      if (!PHOTOS_DIR.exists)
        PHOTOS_DIR.create();
    }
    catch (error)
    {
      console.error(error);
    }

  });

  if (!permission) {
    return <Text>Checking permissions...</Text>;
  }

  if (!permission.granted) {
    return <Text>Camera permission denied</Text>;
  }

  if (!isFocused) {
    return <View/>
  }

  const takePhoto = async  () =>
  {
      try{
      // D.13 Add photo quality optoin here
       const photo = await cameraRef.current?.takePictureAsync();
       if (!photo?.uri)
       {   
          Alert.alert('No Photo', 'Could not capture the photo.');
        return;
       }
        // C.2 REMOVE these lines
        const fileName = 'photo_' + Date.now() + '.jpg';
        const file = new File(PHOTOS_DIR, fileName);
        const sourceFile = new File(photo.uri);
        sourceFile.move(file);

        setPhotoURI(file.uri);
        // UNTIL here

        // C.3 REPLACE file.uri with photo.uri (choose if you want to go to PhotoScreen or AddPostScreen)
        props.navigation.navigate("Photo", {uri: file.uri})
      }
      catch (error)
      {
          Alert.alert('Photo failed', 'Could not capture or store the photo.');
      }
  }

  return (
    <View style={{ flex: 1 }}>
      <CameraView  style={{ flex: 1 }} facing="back" ref={cameraRef}/>
      <Button title="Take Photo" onPress={takePhoto}/>
    </View>
  );
}
