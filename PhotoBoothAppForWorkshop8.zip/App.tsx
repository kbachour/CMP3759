import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import CameraScreen from './screens/CameraScreen';
import GalleryScreen from './screens/GalleryScreen';
import PhotoScreen from './screens/PhotoScreen';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';

const Tab = createBottomTabNavigator();

export default function App() {

  const CameraStack = () => {
    const Stack = createStackNavigator();
    return (
    <Stack.Navigator>
        <Stack.Screen name="Camera" component={CameraScreen}></Stack.Screen>
        <Stack.Screen name="Photo" component={PhotoScreen}></Stack.Screen>
        {/* C.1 REPLACE this line (including the curly braces) with your Stack.Screen component for "Post" */}
    </Stack.Navigator>
    );
  }

  

  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{headerShown: false}}>
        <Tab.Screen
          name="CameraStack"
          component={CameraStack}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="camera" color={color} size={size} />
            ),
            tabBarLabel: "Camera",
          }
        }
        />
        <Tab.Screen
          name="Gallery"
          component={GalleryScreen}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="view-grid" color={color} size={size} />
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}